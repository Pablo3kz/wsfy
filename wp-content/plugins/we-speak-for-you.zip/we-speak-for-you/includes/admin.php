<?php
/*
function wsfy_admin_menu_setup() {
  add_menu_page('We Speak For You', 'We Speak For You', 8, __FILE__, 'wsfy_top_level_page');
}

function wsfy_top_level_page() {
  $html .= "<h2>We Speak For You</h2>";
    


    
  echo $html;
}
 

add_action('admin_menu', 'wsfy_admin_menu_setup');
*/

/*
$args = array( 'post_type' => 'product', 'posts_per_page' => 10 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
  the_title();
  echo '<div class="entry-content">';
  the_content();
  echo '</div>';
endwhile;
*/
?>