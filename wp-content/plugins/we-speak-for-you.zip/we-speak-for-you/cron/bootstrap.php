<?php
    require_once('../../../../wp-load.php');
        
    function perform_job($name, $job) {
        $lock_file = "{$name}.lock";
        
        if (file_exists($lock_file))
            return;
            
        file_put_contents($lock_file, '');
        
        $job();
        
        unlink($lock_file);
    }    
?>