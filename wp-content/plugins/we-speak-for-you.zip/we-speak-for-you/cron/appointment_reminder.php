<?php
    require_once 'bootstrap.php';
    
    perform_job(basename(__FILE__, '.php'), function(){
      wp_mail(
        'pablo3kz@gmail.com ',
        'Bluehost test cron',
        'Test',
        ['Reply-To: '.'pabloII_kz@mail.ru', 'From: '.'Pablo'.' <'.'pabloII_kz@mail.ru'.'>']
      );            
    });
?>